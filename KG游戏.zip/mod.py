def mod():
    print("本插件为默认插件可以进行修改")
